package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BookCoverArt(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .aspectRatio(0.72f)
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF090D16),
                        Color(0xFF1E1B4B),
                        Color(0xFF05050A)
                    )
                )
            )
            .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .shadow(12.dp, RoundedCornerShape(16.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Starry sky dots
            val stars = listOf(
                Offset(w * 0.2f, h * 0.12f),
                Offset(w * 0.8f, h * 0.15f),
                Offset(w * 0.5f, h * 0.08f),
                Offset(w * 0.35f, h * 0.22f),
                Offset(w * 0.65f, h * 0.18f),
                Offset(w * 0.15f, h * 0.28f),
                Offset(w * 0.85f, h * 0.26f)
            )
            stars.forEach { star ->
                drawCircle(
                    color = Color.White.copy(alpha = 0.8f),
                    radius = 2.dp.toPx(),
                    center = star
                )
            }

            // Atmospheric citadel tower silhouette in center
            val towerLeft = w * 0.42f
            val towerRight = w * 0.58f
            val towerTop = h * 0.48f
            val towerBottom = h * 0.82f

            val towerPath = Path().apply {
                moveTo(towerLeft + (towerRight - towerLeft) * 0.15f, towerTop)
                lineTo(towerRight - (towerRight - towerLeft) * 0.15f, towerTop)
                lineTo(towerRight, towerBottom)
                lineTo(towerLeft, towerBottom)
                close()
            }

            drawPath(
                path = towerPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF334155),
                        Color(0xFF1E293B),
                        Color(0xFF0F172A)
                    ),
                    startY = towerTop,
                    endY = towerBottom
                )
            )

            // Tower arched doorway
            val doorPath = Path().apply {
                moveTo(w * 0.47f, towerBottom)
                lineTo(w * 0.47f, towerBottom - h * 0.08f)
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(
                        left = w * 0.47f,
                        top = towerBottom - h * 0.11f,
                        right = w * 0.53f,
                        bottom = towerBottom - h * 0.05f
                    ),
                    startAngleDegrees = 180f,
                    sweepAngleDegrees = 180f,
                    forceMoveTo = false
                )
                lineTo(w * 0.53f, towerBottom)
                close()
            }
            drawPath(path = doorPath, color = Color(0xFF020617))

            // Fog / desert dunes
            val dunePath = Path().apply {
                moveTo(0f, h * 0.78f)
                quadraticBezierTo(w * 0.3f, h * 0.72f, w * 0.6f, h * 0.76f)
                quadraticBezierTo(w * 0.85f, h * 0.8f, w, h * 0.75f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(
                path = dunePath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x8838BDF8),
                        Color(0xCC0F172A),
                        Color(0xFF020617)
                    )
                )
            )

            // Flying bird silhouettes
            val bird1 = Path().apply {
                moveTo(w * 0.68f, h * 0.42f)
                quadraticBezierTo(w * 0.72f, h * 0.40f, w * 0.76f, h * 0.43f)
                quadraticBezierTo(w * 0.73f, h * 0.42f, w * 0.72f, h * 0.44f)
                quadraticBezierTo(w * 0.70f, h * 0.42f, w * 0.68f, h * 0.42f)
                close()
            }
            drawPath(path = bird1, color = Color(0xFF0F172A))

            val bird2 = Path().apply {
                moveTo(w * 0.80f, h * 0.36f)
                quadraticBezierTo(w * 0.83f, h * 0.34f, w * 0.86f, h * 0.37f)
                quadraticBezierTo(w * 0.84f, h * 0.36f, w * 0.83f, h * 0.38f)
                quadraticBezierTo(w * 0.81f, h * 0.36f, w * 0.80f, h * 0.36f)
                close()
            }
            drawPath(path = bird2, color = Color(0xFF0F172A))

            // Glowing diamond emblem at top
            val diamondCenter = Offset(w * 0.5f, h * 0.12f)
            val dSize = w * 0.07f
            val diamondPath = Path().apply {
                moveTo(diamondCenter.x, diamondCenter.y - dSize)
                lineTo(diamondCenter.x + dSize, diamondCenter.y)
                lineTo(diamondCenter.x, diamondCenter.y + dSize)
                lineTo(diamondCenter.x - dSize, diamondCenter.y)
                close()
            }
            drawPath(
                path = diamondPath,
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFE0F2FE), Color(0xFF38BDF8), Color(0x000284C7)),
                    center = diamondCenter,
                    radius = dSize * 1.5f
                )
            )
            drawPath(
                path = diamondPath,
                color = Color(0xFF7DD3FC),
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        // Cover Typography Overlay
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "THE SECRET OF DIAMONDS",
                color = Color(0xFFE2E8F0),
                fontSize = 11.sp,
                letterSpacing = 2.sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "راز الماس",
                color = Color(0xFFF8FAFC),
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.weight(1f))

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF020617).copy(alpha = 0.85f))
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "نویسنده: ابوالفضل پورنجف",
                        color = Color(0xFFBAE6FD),
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ناشر: کانال روایت ما",
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}
