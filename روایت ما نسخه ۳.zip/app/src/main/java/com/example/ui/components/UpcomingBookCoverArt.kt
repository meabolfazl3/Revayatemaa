package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

enum class UpcomingCoverType {
    ALBORZ_SHADOWS,
    CASE_221,
    SILENT_TEMPLE
}

@Composable
fun UpcomingBookCoverArt(
    type: UpcomingCoverType,
    modifier: Modifier = Modifier
) {
    val (bgGradient, borderColor) = when (type) {
        UpcomingCoverType.ALBORZ_SHADOWS -> Pair(
            listOf(Color(0xFF064E3B), Color(0xFF022C22), Color(0xFF0F172A), Color(0xFF030712)),
            Color(0xFF34D399).copy(alpha = 0.35f)
        )
        UpcomingCoverType.CASE_221 -> Pair(
            listOf(Color(0xFF7F1D1D), Color(0xFF450A0A), Color(0xFF1E1B4B), Color(0xFF030712)),
            Color(0xFFF87171).copy(alpha = 0.35f)
        )
        UpcomingCoverType.SILENT_TEMPLE -> Pair(
            listOf(Color(0xFF4C1D95), Color(0xFF2E1065), Color(0xFF172554), Color(0xFF030712)),
            Color(0xFFA78BFA).copy(alpha = 0.35f)
        )
    }

    Box(
        modifier = modifier
            .aspectRatio(0.72f)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(bgGradient))
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .shadow(8.dp, RoundedCornerShape(14.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            when (type) {
                UpcomingCoverType.ALBORZ_SHADOWS -> {
                    // Moon
                    drawCircle(
                        color = Color(0xFFFDE68A).copy(alpha = 0.75f),
                        radius = w * 0.12f,
                        center = Offset(w * 0.75f, h * 0.22f)
                    )
                    drawCircle(
                        color = Color(0xFF064E3B),
                        radius = w * 0.11f,
                        center = Offset(w * 0.72f, h * 0.20f)
                    )

                    // Mountain layers
                    val mtnPath1 = Path().apply {
                        moveTo(0f, h * 0.85f)
                        lineTo(w * 0.35f, h * 0.42f)
                        lineTo(w * 0.7f, h * 0.65f)
                        lineTo(w, h * 0.48f)
                        lineTo(w, h)
                        lineTo(0f, h)
                        close()
                    }
                    drawPath(
                        path = mtnPath1,
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF065F46), Color(0xFF022C22)),
                            startY = h * 0.42f,
                            endY = h
                        )
                    )

                    val mtnPath2 = Path().apply {
                        moveTo(0f, h * 0.62f)
                        lineTo(w * 0.5f, h * 0.52f)
                        lineTo(w, h * 0.72f)
                        lineTo(w, h)
                        lineTo(0f, h)
                        close()
                    }
                    drawPath(
                        path = mtnPath2,
                        color = Color(0xFF021E17).copy(alpha = 0.9f)
                    )

                    // Geometric decorative line
                    drawCircle(
                        color = Color(0xFF34D399).copy(alpha = 0.3f),
                        radius = w * 0.28f,
                        center = Offset(w * 0.5f, h * 0.45f),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }

                UpcomingCoverType.CASE_221 -> {
                    // Detective Noir / Lens geometry
                    drawCircle(
                        color = Color(0xFFEF4444).copy(alpha = 0.25f),
                        radius = w * 0.32f,
                        center = Offset(w * 0.5f, h * 0.42f),
                        style = Stroke(width = 2.dp.toPx())
                    )
                    drawCircle(
                        color = Color(0xFFF59E0B).copy(alpha = 0.2f),
                        radius = w * 0.22f,
                        center = Offset(w * 0.5f, h * 0.42f),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                    drawCircle(
                        color = Color(0xFFF87171).copy(alpha = 0.4f),
                        radius = w * 0.08f,
                        center = Offset(w * 0.5f, h * 0.42f)
                    )

                    // Crosshairs
                    drawLine(
                        color = Color(0xFFEF4444).copy(alpha = 0.4f),
                        start = Offset(w * 0.15f, h * 0.42f),
                        end = Offset(w * 0.85f, h * 0.42f),
                        strokeWidth = 1.5.dp.toPx()
                    )
                    drawLine(
                        color = Color(0xFFEF4444).copy(alpha = 0.4f),
                        start = Offset(w * 0.5f, h * 0.18f),
                        end = Offset(w * 0.5f, h * 0.66f),
                        strokeWidth = 1.5.dp.toPx()
                    )

                    // Diagonal Noir Shadows
                    drawLine(
                        color = Color(0x33000000),
                        start = Offset(0f, h * 0.2f),
                        end = Offset(w, h * 0.8f),
                        strokeWidth = 24.dp.toPx()
                    )
                }

                UpcomingCoverType.SILENT_TEMPLE -> {
                    // Ancient columns & mystic aura
                    drawCircle(
                        color = Color(0xFFA78BFA).copy(alpha = 0.25f),
                        radius = w * 0.3f,
                        center = Offset(w * 0.5f, h * 0.45f),
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Temple roof pediment
                    val roof = Path().apply {
                        moveTo(w * 0.2f, h * 0.38f)
                        lineTo(w * 0.5f, h * 0.26f)
                        lineTo(w * 0.8f, h * 0.38f)
                        close()
                    }
                    drawPath(
                        path = roof,
                        color = Color(0xFF6D28D9).copy(alpha = 0.7f)
                    )

                    // Columns
                    drawRect(
                        color = Color(0xFF5B21B6).copy(alpha = 0.8f),
                        topLeft = Offset(w * 0.25f, h * 0.4f),
                        size = Size(w * 0.08f, h * 0.32f)
                    )
                    drawRect(
                        color = Color(0xFF5B21B6).copy(alpha = 0.8f),
                        topLeft = Offset(w * 0.46f, h * 0.4f),
                        size = Size(w * 0.08f, h * 0.32f)
                    )
                    drawRect(
                        color = Color(0xFF5B21B6).copy(alpha = 0.8f),
                        topLeft = Offset(w * 0.67f, h * 0.4f),
                        size = Size(w * 0.08f, h * 0.32f)
                    )
                }
            }
        }
    }
}
