package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.notification.NovelNotificationHelper
import com.example.ui.HomeScreen
import com.example.ui.ReaderScreen
import com.example.ui.ReaderViewModel
import com.example.ui.ScreenMode
import com.example.ui.theme.NovelThemes
import com.example.ui.theme.RazeAlmasTheme

class MainActivity : ComponentActivity() {
    private val viewModel: ReaderViewModel by viewModels()

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        NovelNotificationHelper.createNotificationChannel(this)
        checkNotificationPermission()
        handleIntent(intent)

        setContent {
            val uiState by viewModel.uiState.collectAsState()
            val sysColors = NovelThemes.getSystemColors(uiState.settings.systemTheme)

            LaunchedEffect(Unit) {
                viewModel.checkAndNotifyNewUnlockedChapters()
            }

            RazeAlmasTheme(
                systemTheme = uiState.settings.systemTheme,
                uiFont = uiState.settings.uiFont,
                uiScalePercent = uiState.settings.uiScalePercent
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = sysColors.bg
                ) {
                    when (uiState.currentScreen) {
                        ScreenMode.HOME -> HomeScreen(viewModel = viewModel, uiState = uiState)
                        ScreenMode.READER -> ReaderScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val targetChId = intent?.getIntExtra(NovelNotificationHelper.EXTRA_CHAPTER_ID, -1) ?: -1
        if (targetChId > 0) {
            viewModel.selectChapterById(targetChId)
            viewModel.navigateToReader()
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

