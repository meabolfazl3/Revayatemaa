package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.NovelRepository
import com.example.data.model.PersianFont
import com.example.data.model.ReaderCanvasTheme
import com.example.data.model.ReaderUiSettings
import com.example.data.model.SystemTheme
import com.example.ui.theme.NovelThemes
import com.example.ui.theme.SystemThemeColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SystemSettingsDialog(
    currentSettings: ReaderUiSettings,
    sysColors: SystemThemeColors,
    onSettingsChanged: (ReaderUiSettings) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .padding(vertical = 24.dp)
                    .testTag("system_settings_dialog"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = sysColors.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, sysColors.border)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                tint = sysColors.accent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "مرکز کنترل سیستم (Telegram Hub)",
                                color = sysColors.text,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("close_system_settings_button")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "بستن", tint = sysColors.textMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Telegram Profile Card
                    Surface(
                        color = sysColors.surfaceGlass,
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, sysColors.border),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppLogo(
                                modifier = Modifier.size(48.dp),
                                shapeRadius = 14.dp,
                                elevation = 2.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = NovelRepository.NOVEL_TITLE,
                                    color = sysColors.text,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "نویسنده: ${NovelRepository.NOVEL_AUTHOR} | کانال: ${NovelRepository.NOVEL_CHANNEL}",
                                    color = sysColors.textMuted,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // System Theme Selector
                    Text(
                        text = "پوسته نرم‌افزار و رابط کاربری",
                        color = sysColors.accent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SystemTheme.values().forEach { themeItem ->
                            val isSelected = currentSettings.systemTheme == themeItem
                            val colors = NovelThemes.getSystemColors(themeItem)

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        onSettingsChanged(currentSettings.copy(systemTheme = themeItem))
                                    }
                                    .padding(4.dp)
                                    .testTag("sys_theme_option_${themeItem.id}")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(colors.surface)
                                        .border(
                                            width = if (isSelected) 3.dp else 1.5.dp,
                                            color = if (isSelected) sysColors.accent else colors.border,
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(colors.primary)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = themeItem.titleFa,
                                    color = if (isSelected) sysColors.accent else sysColors.textMuted,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Global UI Font Selector
                    Text(
                        text = "قلم عمومی منوها و سیستم",
                        color = sysColors.accent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PersianFont.values().forEach { fontItem ->
                            val isSelected = currentSettings.uiFont == fontItem
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        onSettingsChanged(currentSettings.copy(uiFont = fontItem))
                                    }
                                    .testTag("ui_font_${fontItem.name}"),
                                color = if (isSelected) sysColors.primary else sysColors.surface.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) sysColors.accent else sysColors.border
                                )
                            ) {
                                Text(
                                    text = fontItem.titleFa,
                                    color = if (isSelected) Color.White else sysColors.text,
                                    fontSize = 14.sp,
                                    fontFamily = NovelThemes.getFontFamily(fontItem),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // UI Scaling Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "اندازه المان‌های پنل (UI Scaling)",
                            color = sysColors.text,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Surface(
                            color = sysColors.accent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "${currentSettings.uiScalePercent}٪",
                                color = sysColors.accent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Slider(
                        value = currentSettings.uiScalePercent.toFloat(),
                        onValueChange = {
                            onSettingsChanged(currentSettings.copy(uiScalePercent = it.toInt()))
                        },
                        valueRange = 85f..125f,
                        steps = 7,
                        colors = SliderDefaults.colors(
                            thumbColor = sysColors.primary,
                            activeTrackColor = sysColors.primary,
                            inactiveTrackColor = sysColors.border
                        ),
                        modifier = Modifier.testTag("ui_scale_slider")
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderSettingsDialog(
    currentSettings: ReaderUiSettings,
    sysColors: SystemThemeColors,
    onSettingsChanged: (ReaderUiSettings) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .padding(vertical = 24.dp)
                    .testTag("reader_settings_dialog"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = sysColors.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, sysColors.border)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = sysColors.accent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تنظیمات قلم و بوم خواندن رمان",
                                color = sysColors.text,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("close_reader_settings_button")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "بستن", tint = sysColors.textMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Reader Canvas Theme Selector (6 options)
                    Text(
                        text = "پس‌زمینه بوم مطالعه",
                        color = sysColors.accent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ReaderCanvasTheme.values().forEach { readerThemeItem ->
                            val isSelected = currentSettings.readerTheme == readerThemeItem
                            val colors = NovelThemes.getReaderColors(readerThemeItem)

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        onSettingsChanged(currentSettings.copy(readerTheme = readerThemeItem))
                                    }
                                    .padding(4.dp)
                                    .testTag("reader_theme_option_${readerThemeItem.id}")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(colors.bg)
                                        .border(
                                            width = if (isSelected) 3.dp else 1.5.dp,
                                            color = if (isSelected) sysColors.accent else colors.title,
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "الف",
                                        color = colors.text,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = readerThemeItem.titleFa,
                                    color = if (isSelected) sysColors.accent else sysColors.textMuted,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Reader Font Family Selector (6 options)
                    Text(
                        text = "قلم ادبی متن رمان",
                        color = sysColors.accent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PersianFont.values().forEach { fontItem ->
                            val isSelected = currentSettings.readerFont == fontItem
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        onSettingsChanged(currentSettings.copy(readerFont = fontItem))
                                    }
                                    .testTag("reader_font_${fontItem.name}"),
                                color = if (isSelected) sysColors.primary else sysColors.surface.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) sysColors.accent else sysColors.border
                                )
                            ) {
                                Text(
                                    text = fontItem.titleFa,
                                    color = if (isSelected) Color.White else sysColors.text,
                                    fontSize = 14.sp,
                                    fontFamily = NovelThemes.getFontFamily(fontItem),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Font Size Slider (15sp to 36sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "اندازه قلم متن",
                            color = sysColors.text,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Surface(
                            color = sysColors.accent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "${currentSettings.fontSizeSp.toInt()} sp",
                                color = sysColors.accent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Slider(
                        value = currentSettings.fontSizeSp,
                        onValueChange = {
                            onSettingsChanged(currentSettings.copy(fontSizeSp = it))
                        },
                        valueRange = 15f..36f,
                        steps = 20,
                        colors = SliderDefaults.colors(
                            thumbColor = sysColors.primary,
                            activeTrackColor = sysColors.primary,
                            inactiveTrackColor = sysColors.border
                        ),
                        modifier = Modifier.testTag("reader_font_size_slider")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Line Height Multiplier Slider (1.6 to 3.0)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "فاصله خطوط",
                            color = sysColors.text,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Surface(
                            color = sysColors.accent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = String.format(java.util.Locale.US, "%.1fx", currentSettings.lineHeightMultiplier),
                                color = sysColors.accent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Slider(
                        value = currentSettings.lineHeightMultiplier,
                        onValueChange = {
                            onSettingsChanged(currentSettings.copy(lineHeightMultiplier = it))
                        },
                        valueRange = 1.6f..3.0f,
                        steps = 14,
                        colors = SliderDefaults.colors(
                            thumbColor = sysColors.primary,
                            activeTrackColor = sysColors.primary,
                            inactiveTrackColor = sysColors.border
                        ),
                        modifier = Modifier.testTag("reader_line_height_slider")
                    )
                }
            }
        }
    }
}
