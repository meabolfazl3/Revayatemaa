package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun AppLogo(
    modifier: Modifier = Modifier.size(48.dp),
    shapeRadius: Dp = 14.dp,
    elevation: Dp = 0.dp
) {
    Box(
        modifier = modifier
            .then(if (elevation > 0.dp) Modifier.shadow(elevation, RoundedCornerShape(shapeRadius)) else Modifier)
            .clip(RoundedCornerShape(shapeRadius))
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFFFFFF),
                        Color(0xFFF9F5EE),
                        Color(0xFFEDE5D8)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            drawAppBrandLogo(this)
        }
    }
}

private fun drawAppBrandLogo(drawScope: DrawScope) {
    val w = drawScope.size.width
    val h = drawScope.size.height

    // Helper scale function: normalizes 0..100 coordinates to actual size
    fun sx(x: Float): Float = (x / 100f) * w
    fun sy(y: Float): Float = (y / 100f) * h

    // 1. Top Sparkle Star (Golden 4-point star)
    val starPath = Path().apply {
        moveTo(sx(50f), sy(18f))
        cubicTo(sx(50.4f), sy(22.8f), sx(52.2f), sy(24.6f), sx(57f), sy(25f))
        cubicTo(sx(52.2f), sy(25.4f), sx(50.4f), sy(27.2f), sx(50f), sy(32f))
        cubicTo(sx(49.6f), sy(27.2f), sx(47.8f), sy(25.4f), sx(43f), sy(25f))
        cubicTo(sx(47.8f), sy(24.6f), sx(49.6f), sy(22.8f), sx(50f), sy(18f))
        close()
    }
    drawScope.drawPath(
        path = starPath,
        color = Color(0xFFD9A443),
        style = Fill
    )

    // 2. Open Navy Book Base
    val bookBase = Path().apply {
        moveTo(sx(16f), sy(42f))
        cubicTo(sx(27f), sy(33f), sx(41f), sy(37f), sx(50f), sy(44f))
        cubicTo(sx(59f), sy(37f), sx(73f), sy(33f), sx(84f), sy(42f))
        lineTo(sx(84f), sy(74f))
        cubicTo(sx(73f), sy(67f), sx(59f), sy(70f), sx(50f), sy(78f))
        cubicTo(sx(41f), sy(70f), sx(27f), sy(67f), sx(16f), sy(74f))
        close()
    }
    drawScope.drawPath(
        path = bookBase,
        color = Color(0xFF091C3B),
        style = Fill
    )

    // 3. Book Bottom Spine Shadow
    val bookSpine = Path().apply {
        moveTo(sx(16f), sy(74f))
        cubicTo(sx(27f), sy(67f), sx(41f), sy(70f), sx(50f), sy(78f))
        cubicTo(sx(59f), sy(70f), sx(73f), sy(67f), sx(84f), sy(74f))
        lineTo(sx(84f), sy(78f))
        cubicTo(sx(73f), sy(71f), sx(59f), sy(74f), sx(50f), sy(82f))
        cubicTo(sx(41f), sy(74f), sx(27f), sy(71f), sx(16f), sy(78f))
        close()
    }
    drawScope.drawPath(
        path = bookSpine,
        color = Color(0xFF040D1D),
        style = Fill
    )

    // 4. White Page Inner Contour Lines
    val leftPageLine = Path().apply {
        moveTo(sx(20f), sy(45f))
        cubicTo(sx(29f), sy(38f), sx(41f), sy(41f), sx(48f), sy(47f))
        lineTo(sx(48f), sy(76f))
        cubicTo(sx(41f), sy(71f), sx(29f), sy(68f), sx(20f), sy(73f))
        close()
    }
    drawScope.drawPath(
        path = leftPageLine,
        color = Color.White,
        style = Stroke(
            width = (w * 0.024f).coerceAtLeast(1.5f),
            join = StrokeJoin.Round
        )
    )

    val rightPageLine = Path().apply {
        moveTo(sx(80f), sy(45f))
        cubicTo(sx(71f), sy(38f), sx(59f), sy(41f), sx(52f), sy(47f))
        lineTo(sx(52f), sy(76f))
        cubicTo(sx(59f), sy(71f), sx(71f), sy(68f), sx(80f), sy(73f))
        close()
    }
    drawScope.drawPath(
        path = rightPageLine,
        color = Color.White,
        style = Stroke(
            width = (w * 0.024f).coerceAtLeast(1.5f),
            join = StrokeJoin.Round
        )
    )

    // 5. Golden Quill Feather Silhouette (diagonal across book)
    val featherGradient = Brush.linearGradient(
        colors = listOf(
            Color(0xFFC68B25),
            Color(0xFFE5B552),
            Color(0xFFF7DB8E)
        ),
        start = Offset(sx(44f), sy(65f)),
        end = Offset(sx(82f), sy(12f))
    )

    val quillFeather = Path().apply {
        moveTo(sx(44f), sy(65f))
        cubicTo(sx(45f), sy(62f), sx(47f), sy(55f), sx(50f), sy(48f))
        cubicTo(sx(53f), sy(41f), sx(58f), sy(32f), sx(68f), sy(22f))
        cubicTo(sx(77f), sy(13f), sx(82.5f), sy(11f), sx(83f), sy(11f))
        cubicTo(sx(83f), sy(11.5f), sx(82f), sy(19f), sx(79f), sy(26f))
        cubicTo(sx(76f), sy(32f), sx(70f), sy(43f), sx(59f), sy(52f))
        cubicTo(sx(53f), sy(57f), sx(47f), sy(61f), sx(44f), sy(65f))
        close()
    }
    drawScope.drawPath(
        path = quillFeather,
        brush = featherGradient,
        style = Fill
    )

    // Feather Vane / Indentation cut
    val quillVane = Path().apply {
        moveTo(sx(50f), sy(48f))
        cubicTo(sx(45f), sy(43f), sx(42f), sy(36f), sx(47f), sy(27f))
        cubicTo(sx(49f), sy(23f), sx(51f), sy(21f), sx(51f), sy(21f))
        cubicTo(sx(51f), sy(21f), sx(51f), sy(26f), sx(53f), sy(31f))
        cubicTo(sx(55f), sy(37f), sx(59f), sy(44f), sx(61f), sy(50f))
        close()
    }
    drawScope.drawPath(
        path = quillVane,
        color = Color(0xFFDFAC46),
        style = Fill
    )

    // Quill Shaft / Central Spine Line
    drawScope.drawLine(
        color = Color(0xFFFFF1D6),
        start = Offset(sx(43.5f), sy(67f)),
        end = Offset(sx(78f), sy(17f)),
        strokeWidth = (w * 0.02f).coerceAtLeast(1.2f),
        cap = StrokeCap.Round
    )

    // Quill Nib Tip
    val nibPath = Path().apply {
        moveTo(sx(43.5f), sy(67f))
        lineTo(sx(45.5f), sy(63f))
        lineTo(sx(42f), sy(65f))
        close()
    }
    drawScope.drawPath(
        path = nibPath,
        color = Color(0xFFB0761A),
        style = Fill
    )
}
